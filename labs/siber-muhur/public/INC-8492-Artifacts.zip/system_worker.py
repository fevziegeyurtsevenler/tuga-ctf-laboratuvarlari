#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket
import base64
import time
import sys

C2_AUTH_BLOB = "545547417b6e3163335f7472795f6275745f66346b337d"
C2_LISTENER_PORT = 1337

P1 = "VFVHQXtwM3JzMX"
P2 = "N0M25jM190aHIw"
P3 = "dWdoXzV5c3QzbWR9"

def establish_heartbeat():
    try:
        auth_token = base64.b64decode(P1 + P2 + P3).decode('utf-8')
        
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('0.0.0.0', C2_LISTENER_PORT))
        s.listen(1)
        
        while True:
            time.sleep(60)
            
    except Exception as e:
        sys.exit(1)

if __name__ == "__main__":
    establish_heartbeat()